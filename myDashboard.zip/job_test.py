# TESTING MODEL

import joblib

model = joblib.load('modelJoblib')

# Prediksi probability of default
# User mengisi data
print(model.predict([[3000,10000,30,30,10]])[0])
 
