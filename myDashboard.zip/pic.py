import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import xgboost as xgb
import pickle

# Load dataset
df = pd.read_csv('dataset.csv')
 
# Fill missing value
df['loan_int_rate'] = df['loan_int_rate'].mask(df['loan_grade'] == 'A', df['loan_int_rate'].fillna(7.33))
df['loan_int_rate'] = df['loan_int_rate'].mask(df['loan_grade'] == 'B', df['loan_int_rate'].fillna(11.00))
df['loan_int_rate'] = df['loan_int_rate'].mask(df['loan_grade'] == 'C', df['loan_int_rate'].fillna(13.46))
df['loan_int_rate'] = df['loan_int_rate'].mask(df['loan_grade'] == 'D', df['loan_int_rate'].fillna(15.36))
df['loan_int_rate'] = df['loan_int_rate'].mask(df['loan_grade'] == 'E', df['loan_int_rate'].fillna(17.01))
df['loan_int_rate'] = df['loan_int_rate'].mask(df['loan_grade'] == 'F', df['loan_int_rate'].fillna(18.26))
df['loan_int_rate'] = df['loan_int_rate'].mask(df['loan_grade'] == 'G', df['loan_int_rate'].fillna(20.25))

# Float to integer 
df['loan_int_rate'] = df['loan_int_rate'].astype(int)
df['loan_percent_income'] = df['loan_percent_income'].astype(int)
df['person_emp_length'] = df['person_emp_length'].astype(int)

# Splitting data
X = df[['person_income','loan_amnt','loan_percent_income', 'loan_int_rate','person_emp_length']]
y = df[['loan_status']]

# Dataframe to numpy
X = X.to_numpy()
y = y.to_numpy()

# Use test_train_split to create the training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=101)

# Modeling
model = LogisticRegression(max_iter=100, penalty='l2', solver='newton-cg').fit(X_train, np.ravel(y_train))

with open('modelPickle', 'wb') as modelku:
    pickle.dump(model, modelku)

