# TESTING MODEL

import pickle

with open('modelPickle','rb') as modelku:
    model = pickle.load(modelku)

# Prediksi probability of default
# User mengisi data
print(model.predict([[3000,10000,30,30,10]])[0])
 
